import pandas as pd
import traceback
import httpx
from openai import OpenAI
import time
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


http_client = httpx.Client()
client = OpenAI(
    api_key="unused",
    base_url="https://aigateway.instacart.tools/unified/product_matches/v1",
    http_client=http_client
)

def get_response(prompt):
    try:
        response = client.chat.completions.create(
            model="claude-3.7-sonnet",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1000,
            temperature=0
        )
        return response.choices[0].message.content.strip()
    except Exception:
        traceback.print_exc()
        return None

def validate_product_category_match(product_name, product_category_path):
    """
    Validate if the product name matches the assigned product category path.
    Returns 'Yes' if they match, 'No' if they don't.
    """
    # Create a prompt for the AI with examples
    prompt = f"""
    Validate if the value in PRODUCT_NAME and PRODUCT_CATEGORY_PATH are the same.
    The answer should only be yes/no.
    
    Here are examples of how the fields should be validated:
    
    PRODUCT_NAME: Primal Kitchen Cocktail Sauce, Organic and Unsweetened
    PRODUCT_CATEGORY_PATH: Food > Pantry > Condiments > Sauces > Cocktail Sauce
    Taxonomy_Match: Yes

    PRODUCT_NAME: Tom's Mountain Spring Natural Deodorant For Men And Women, Aluminum Free
    PRODUCT_CATEGORY_PATH: Personal Care > Deodorants and Antiperspirants > Deodorants
    Taxonomy_Match: Yes

    PRODUCT_NAME: Philips Avent Avent Natural Baby Bottle With Natural Response Nipple, Clear, 9oz, SCY903/03
    PRODUCT_CATEGORY_PATH: Baby > Baby Feeding > Baby Bottles
    Taxonomy_Match: Yes

    PRODUCT_NAME: Assorted Desert Afterglow Detangler
    PRODUCT_CATEGORY_PATH: Personal Care > Deodorants and Antiperspirants > Deodorants
    Taxonomy_Match: No

    PRODUCT_NAME: Assorted Desert Afterglow Detangler
    PRODUCT_CATEGORY_PATH: Craft and Hobby > Hobby Supplies > Sewing and Quilting Supplies > Craft Fabrics
    Taxonomy_Match: No

    PRODUCT_NAME: Assorted Desert Afterglow Detangler
    PRODUCT_CATEGORY_PATH: Personal Care > Hair Care > Hair Styling Products > Detanglers
    Taxonomy_Match: Yes

    PRODUCT_NAME: R/W Imported Bone-In Lamb Shoulder
    PRODUCT_CATEGORY_PATH: Food > Meat > Poultry > Chicken > Whole Chicken
    Taxonomy_Match: No

    PRODUCT_NAME: Imported Skin-Off Whole Goat
    PRODUCT_CATEGORY_PATH: Food > Meat > Beef
    Taxonomy_Match: No

    PRODUCT_NAME: Whole Cooked Crawfish
    PRODUCT_CATEGORY_PATH: Food > Meat > Pork > Ham Roast
    Taxonomy_Match: No
    
    Now validate this product:
    PRODUCT_NAME: {product_name}
    PRODUCT_CATEGORY_PATH: {product_category_path}
    Taxonomy_Match: 
    """
    
    # Get response from AI
    response = get_response(prompt)
    
    # Process response to ensure it's just Yes or No
    if response:
        if 'yes' in response.lower():
            return 'Yes'
        elif 'no' in response.lower():
            return 'No'
        else:
            # If response isn't clearly Yes or No, try to extract it
            if 'taxonomy_match: yes' in response.lower():
                return 'Yes'
            elif 'taxonomy_match: no' in response.lower():
                return 'No'
            else:
                # Default to No if unclear
                return 'No'
    else:
        return 'Error'

def process_batch(df, taxonomy_df, batch_size=10):
    """Process dataframe in batches to avoid rate limiting."""
    results = []
    total_rows = len(df)
    
    # Extract the list of all taxonomies
    #taxonomy_list = taxonomy_df['Category_path'].tolist()
    
    # Create example products dictionary for reference
    example_products = {
        "Primal Kitchen Cocktail Sauce, Organic and Unsweetened": "Food > Pantry > Condiments > Sauces > Cocktail Sauce",
        "Tom's Mountain Spring Natural Deodorant For Men And Women, Aluminum Free": "Personal Care > Deodorants and Antiperspirants > Deodorants",
        "Philips Avent Avent Natural Baby Bottle With Natural Response Nipple, Clear, 9oz, SCY903/03": "Baby > Baby Feeding > Baby Bottles",
        "R/W Imported Bone-In Lamb Shoulder": "Food > Meat > Lamb",
        "Imported Skin-Off Whole Goat": "Food > Meat > Goat",
        "Whole Cooked Crawfish": "Food > Seafood > Shellfish > Crawfish"
    }
    
    for i in range(0, total_rows, batch_size):
        batch = df.iloc[i:i+batch_size]
        print(f"Processing batch {i//batch_size + 1}/{(total_rows-1)//batch_size + 1} ({i+1}-{min(i+batch_size, total_rows)} of {total_rows})")
        
        for _, row in batch.iterrows():
            product_name = row['PRODUCT_NAME']
            product_category_path = row['PRODUCT_CATEGORY_PATH']
            
            print(f"Validating: {product_name[:30]}... against {product_category_path[:30]}...")
            match_result = validate_product_category_match(product_name, product_category_path)
            print(f"Result: {match_result}")
            
            # No suggested taxonomy for now
            results.append({
                'PRODUCT_NAME': product_name,
                'PRODUCT_CATEGORY_PATH': product_category_path,
                'TAXONOMY_MATCH': match_result,
                #'Suggested_Taxonomy': ""
            })
        
        # Add a small delay between batches to avoid rate limiting
        time.sleep(2)
    
    return pd.DataFrame(results)

def main():
    try:
        input_file = 'Name_Vs_Taxonomy_Audit_Input.xlsx'
        df_input = pd.read_excel(input_file)
        
        taxonomy_file = 'taxonomy_list.csv'
        df_taxonomy = pd.read_csv(taxonomy_file)
        
        print(f"Loaded {len(df_input)} products from input file")
        print(f"Loaded {len(df_taxonomy)} taxonomies from taxonomy list")
        
        # Process the data
        df_output = process_batch(df_input, df_taxonomy)
        
        # Write to output file
        output_file = 'Name_Vs_Taxonomy_Audit_Output.xlsx'
        df_output.to_excel(output_file, index=False)
        
        print(f"Validation complete. Results written to {output_file}")
        
        # Print summary
        yes_count = (df_output['TAXONOMY_MATCH'] == 'Yes').sum()
        no_count = (df_output['TAXONOMY_MATCH'] == 'No').sum()
        error_count = (df_output['TAXONOMY_MATCH'] == 'Error').sum()
        
        print(f"Summary: {yes_count} matches, {no_count} non-matches, {error_count} errors")
        
    except Exception as e:
        print(f"Error: {str(e)}")
        traceback.print_exc()

if __name__ == "__main__":
    main()