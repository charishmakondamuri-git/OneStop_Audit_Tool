import streamlit as st
import pandas as pd
import os
import time
import sys
import tempfile
from datetime import datetime

# Add the current directory to the path to ensure modules can be found
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Page configuration
st.set_page_config(
    page_title="OneStop Audit Tool",
    page_icon="🔍",
    layout="wide"
)

# Title and description
st.title("🔍 OneStop Audit Tool")
st.markdown("A comprehensive tool for auditing product data across various dimensions.")

# Create tabs for navigation
tab1, tab2, tab3, tab4 = st.tabs([
    "🔤 Name Audit", 
    "🖼️ Image vs Image", 
    "🔤🖼️ Name vs Image", 
    "🔤📊 Name vs Taxonomy"
])

# Function to display audit instructions based on type
def show_audit_instructions(audit_type):
    if audit_type == "Name Audit":
        return """
        ### Instructions
        
        This audit checks if two product names refer to the same product despite wording differences.
        
        **Required columns:**
        - RAW_NAME: The original product name
        - DISPLAY_NAME: The displayed product name
        
        **Output:**
        - NAME_MATCH: Yes/No indicating if the names match
        """
    elif audit_type == "Image vs Image Audit":
        return """
        ### Instructions
        
        This audit compares two product images to determine if they show the same product.
        
        **Required columns:**
        - IMAGE_URL_1: URL of the first image
        - IMAGE_URL_2: URL of the second image
        
        **Output:**
        - IMAGE_MATCH: Yes/No indicating if images match
        - CONFIDENCE: Confidence score (0.0-1.0)
        """
    elif audit_type == "Name vs Image Audit":
        return """
        ### Instructions
        
        This audit checks if a product image matches the product name.
        
        **Required columns:**
        - DISPLAY_NAME: The product name
        - IMAGE_URL: URL of the product image
        
        **Output:**
        - IMAGE_MATCH: Yes/No indicating if the image matches the name
        - CONFIDENCE: Confidence score (0.0-1.0)
        """
    elif audit_type == "Name vs Taxonomy Audit":
        return """
        ### Instructions
        
        This audit validates if a product name matches its assigned category path.
        
        **Required columns:**
        - PRODUCT_NAME: The product name
        - PRODUCT_CATEGORY_PATH: The taxonomy category path
        
        **Output:**
        - TAXONOMY_MATCH: Yes/No indicating if the name matches the taxonomy
        """

# Define output file paths for each audit type
OUTPUT_FILES = {
    "Name Audit": "Name_Audit_Output.xlsx",
    "Image vs Image Audit": "Image_Vs_Image_Audit_Output.xlsx",
    "Name vs Image Audit": "Name_Vs_Image_Audit_Output.xlsx",
    "Name vs Taxonomy Audit": "Name_Vs_Taxonomy_Audit_Output.xlsx"
}

# Function to process the audit
def process_audit(audit_type, uploaded_file):
    # Get file extension
    file_extension = uploaded_file.name.split(".")[-1]
    
    # Create a progress bar and status text
    progress_bar = st.progress(0)
    status_text = st.empty()
    progress_metrics = st.empty()
    
    try:
        status_text.text("Starting audit process...")
        
        # Create a temporary file for processing
        with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file_extension}") as temp_file:
            temp_file_path = temp_file.name
            
            # Reset the file pointer to the beginning and save to temp file
            uploaded_file.seek(0)
            temp_file.write(uploaded_file.getbuffer())
        
        try:
            # Get the appropriate output file path
            output_file_path = OUTPUT_FILES[audit_type]
            
            if audit_type == "Name Audit":
                # Read the uploaded file into a DataFrame to get the total count
                if file_extension == "xlsx":
                    df = pd.read_excel(temp_file_path)
                else:
                    df = pd.read_csv(temp_file_path)
                
                total_items = len(df)
                status_text.text(f"Processing Name Audit ({total_items} items)...")
                progress_metrics.text(f"0/{total_items} items processed (0%)")
                
                # Custom progress callback function
                def progress_callback(current, total):
                    progress = min(current / total, 1.0)
                    progress_bar.progress(progress)
                    progress_metrics.text(f"{current}/{total} items processed ({int(progress * 100)}%)")
                
                # Import the module here to avoid initial loading issues
                from Name_Audit import process_excel as process_name_audit
                
                # Monkey patch the print function in Name_Audit to capture progress
                import builtins
                original_print = builtins.print
                
                def custom_print(*args, **kwargs):
                    output = " ".join(str(arg) for arg in args)
                    if "Row" in output and "/" in output and "Name_Match" in output:
                        try:
                            # Extract current row number
                            current = int(output.split("Row")[1].split("/")[0].strip())
                            progress_callback(current, total_items)
                        except:
                            pass
                    return original_print(*args, **kwargs)
                
                builtins.print = custom_print
                
                try:
                    # Run the name audit process on the temp file
                    process_name_audit(temp_file_path, output_file_path)
                finally:
                    # Restore original print function
                    builtins.print = original_print
                
                progress_bar.progress(1.0)
                progress_metrics.text(f"{total_items}/{total_items} items processed (100%)")
                
            elif audit_type == "Image vs Image Audit":
                # Read the uploaded file into a DataFrame to get the total count
                if file_extension == "xlsx":
                    df = pd.read_excel(temp_file_path)
                else:
                    df = pd.read_csv(temp_file_path)
                
                total_items = len(df)
                status_text.text(f"Processing Image vs Image Audit ({total_items} items)...")
                progress_metrics.text(f"0/{total_items} items processed (0%)")
                
                # Import the module here to avoid initial loading issues
                from Image_Vs_Image_Audit import run_pipeline as process_image_image_audit
                
                # Monkey patch the print function to capture progress
                import builtins
                original_print = builtins.print
                
                def custom_print(*args, **kwargs):
                    output = " ".join(str(arg) for arg in args)
                    if "Processing" in output and "/" in output:
                        try:
                            # Extract current row number
                            current = int(output.split("Processing")[1].split("/")[0].strip())
                            progress = min(current / total_items, 1.0)
                            progress_bar.progress(progress)
                            progress_metrics.text(f"{current}/{total_items} items processed ({int(progress * 100)}%)")
                        except:
                            pass
                    return original_print(*args, **kwargs)
                
                builtins.print = custom_print
                
                try:
                    # Run the image vs image audit
                    results_df = process_image_image_audit(temp_file_path, output_file_path)
                finally:
                    # Restore original print function
                    builtins.print = original_print
                
                progress_bar.progress(1.0)
                progress_metrics.text(f"{total_items}/{total_items} items processed (100%)")
                
            elif audit_type == "Name vs Image Audit":
                # Read the uploaded file into a DataFrame to get the total count
                if file_extension == "xlsx":
                    df = pd.read_excel(temp_file_path)
                else:
                    df = pd.read_csv(temp_file_path)
                
                total_items = len(df)
                status_text.text(f"Processing Name Vs Image Audit ({total_items} items)...")
                progress_metrics.text(f"0/{total_items} items processed (0%)")
                
                # Import the module here to avoid initial loading issues
                from Name_Vs_Image_Audit import run_pipeline as process_name_image_audit
                
                # Monkey patch the print function to capture progress
                import builtins
                original_print = builtins.print
                
                def custom_print(*args, **kwargs):
                    output = " ".join(str(arg) for arg in args)
                    if "Processing" in output and "/" in output:
                        try:
                            # Extract current row number
                            current = int(output.split("Processing")[1].split("/")[0].strip())
                            progress = min(current / total_items, 1.0)
                            progress_bar.progress(progress)
                            progress_metrics.text(f"{current}/{total_items} items processed ({int(progress * 100)}%)")
                        except:
                            pass
                    return original_print(*args, **kwargs)
                
                builtins.print = custom_print
                
                try:
                    # Run the name vs image audit
                    results_df = process_name_image_audit(temp_file_path, output_file_path)
                finally:
                    # Restore original print function
                    builtins.print = original_print
                
                progress_bar.progress(1.0)
                progress_metrics.text(f"{total_items}/{total_items} items processed (100%)")
                
            elif audit_type == "Name vs Taxonomy Audit":
                # Read the uploaded file into a DataFrame
                if file_extension == "xlsx":
                    df_preview = pd.read_excel(temp_file_path)
                else:
                    df_preview = pd.read_csv(temp_file_path)
                
                total_items = len(df_preview)
                status_text.text(f"Processing Name vs Taxonomy Audit ({total_items} items)...")
                progress_metrics.text(f"0/{total_items} items processed (0%)")
                
                # Import the module here to avoid initial loading issues
                from Name_Vs_Taxonomy_Audit import process_batch as process_name_taxonomy_audit
                
                # For Name vs Taxonomy, we need to load the taxonomy list
                taxonomy_df = pd.read_csv("taxonomy_list.csv")
                
                # Monkey patch the print function to capture progress
                import builtins
                original_print = builtins.print
                
                processed_count = 0
                
                def custom_print(*args, **kwargs):
                    nonlocal processed_count
                    output = " ".join(str(arg) for arg in args)
                    if "Validating:" in output:
                        processed_count += 1
                        progress = min(processed_count / total_items, 1.0)
                        progress_bar.progress(progress)
                        progress_metrics.text(f"{processed_count}/{total_items} items processed ({int(progress * 100)}%)")
                    return original_print(*args, **kwargs)
                
                builtins.print = custom_print
                
                try:
                    # Run the name vs taxonomy audit with batch size of 10
                    results_df = process_name_taxonomy_audit(df_preview, taxonomy_df, batch_size=10)
                    results_df.to_excel(output_file_path, index=False)
                finally:
                    # Restore original print function
                    builtins.print = original_print
                
                progress_bar.progress(1.0)
                progress_metrics.text(f"{total_items}/{total_items} items processed (100%)")
            
            status_text.text("Audit completed successfully!")
            
            # Display results
            st.success(f"{audit_type} completed successfully!")
            
            # Read and display results
            if output_file_path.endswith('.xlsx'):
                result_df = pd.read_excel(output_file_path)
            else:
                result_df = pd.read_csv(output_file_path)
            
            st.subheader("Audit Results")
            st.dataframe(result_df)
            
            # Download button for results
            with open(output_file_path, "rb") as file:
                st.download_button(
                    label="Download Results",
                    data=file,
                    file_name=os.path.basename(output_file_path),
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" if output_file_path.endswith('.xlsx') else "text/csv"
                )
        
        finally:
            # Clean up the temporary file
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)
        
    except Exception as e:
        st.error(f"An error occurred: {str(e)}")
        st.exception(e)

# Name Audit Tab
with tab1:
    st.header("Name Audit")
    st.info(show_audit_instructions("Name Audit"))
    
    uploaded_file = st.file_uploader("Upload Excel file for Name Audit", type=["xlsx"], key="name_audit_uploader")
    
    if uploaded_file:
        # Read and display preview
        file_extension = uploaded_file.name.split(".")[-1]
        if file_extension == "xlsx":
            df_preview = pd.read_excel(uploaded_file)
        else:
            df_preview = pd.read_csv(uploaded_file)
        
        st.subheader("Preview of uploaded data")
        st.dataframe(df_preview.head(5))
        
        # Process button
        if st.button("Run Name Audit", type="primary", key="name_audit_button"):
            process_audit("Name Audit", uploaded_file)

# Image vs Image Audit Tab
with tab2:
    st.header("Image vs Image Audit")
    st.info(show_audit_instructions("Image vs Image Audit"))
    
    uploaded_file = st.file_uploader("Upload Excel file for Image vs Image Audit", type=["xlsx"], key="image_image_audit_uploader")
    
    if uploaded_file:
        # Read and display preview
        file_extension = uploaded_file.name.split(".")[-1]
        if file_extension == "xlsx":
            df_preview = pd.read_excel(uploaded_file)
        else:
            df_preview = pd.read_csv(uploaded_file)
        
        st.subheader("Preview of uploaded data")
        st.dataframe(df_preview.head(5))
        
        # Process button
        if st.button("Run Image vs Image Audit", type="primary", key="image_image_audit_button"):
            process_audit("Image vs Image Audit", uploaded_file)

# Name vs Image Audit Tab
with tab3:
    st.header("Name vs Image Audit")
    st.info(show_audit_instructions("Name vs Image Audit"))
    
    uploaded_file = st.file_uploader("Upload Excel file for Name vs Image Audit", type=["xlsx"], key="name_image_audit_uploader")
    
    if uploaded_file:
        # Read and display preview
        file_extension = uploaded_file.name.split(".")[-1]
        if file_extension == "xlsx":
            df_preview = pd.read_excel(uploaded_file)
        else:
            df_preview = pd.read_csv(uploaded_file)
        
        st.subheader("Preview of uploaded data")
        st.dataframe(df_preview.head(5))
        
        # Process button
        if st.button("Run Name vs Image Audit", type="primary", key="name_image_audit_button"):
            process_audit("Name vs Image Audit", uploaded_file)

# Name vs Taxonomy Audit Tab
with tab4:
    st.header("Name vs Taxonomy Audit")
    st.info(show_audit_instructions("Name vs Taxonomy Audit"))
    
    uploaded_file = st.file_uploader("Upload Excel file for Name vs Taxonomy Audit", type=["xlsx"], key="name_taxonomy_audit_uploader")
    
    if uploaded_file:
        # Read and display preview
        file_extension = uploaded_file.name.split(".")[-1]
        if file_extension == "xlsx":
            df_preview = pd.read_excel(uploaded_file)
        else:
            df_preview = pd.read_csv(uploaded_file)
        
        st.subheader("Preview of uploaded data")
        st.dataframe(df_preview.head(5))
        
        # Process button
        if st.button("Run Name vs Taxonomy Audit", type="primary", key="name_taxonomy_audit_button"):
            process_audit("Name vs Taxonomy Audit", uploaded_file)

