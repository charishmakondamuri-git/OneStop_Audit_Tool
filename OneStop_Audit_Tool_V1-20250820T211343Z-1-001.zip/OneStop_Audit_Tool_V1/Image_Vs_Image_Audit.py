import pandas as pd
import time
import base64
import requests
import json
import httpx
from openai import OpenAI

http_client = httpx.Client()

class ImageComparator:
    def __init__(self):
        self.client = OpenAI(
            api_key="unused",
            base_url="https://aigateway.instacart.tools/unified/Image_comparision/v1",
            http_client=http_client
        )
        
    def _encode_image(self, url):
        """Download and encode image to base64"""
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return base64.b64encode(response.content).decode('utf-8')
        except Exception as e:
            print(f"Image encoding error: {e}")
            return None
            
    def _get_response(self, messages):
        """Get LLM response with retry"""
        for attempt in range(3):
            try:
                response = self.client.chat.completions.create(
                    model="claude-3.7-sonnet",
                    messages=messages,
                    max_tokens=500,
                    temperature=0
                )
                return response.choices[0].message.content.strip()
            except Exception as e:
                if attempt < 2:
                    time.sleep(2)
                    print(f"Retrying after error: {e}")
                else:
                    print(f"API call failed after retries: {e}")
                    return None
                    
    def _parse_json_response(self, response):
        """Parse JSON response with fallback"""
        if not response:
            return {
                "match": False,
                "confidence": 0.0,
                "explanation": "No response received"
            }
            
        try:
            return json.loads(response)
        except:
            # Fallback parsing
            match = "true" in response.lower() and "match" in response.lower()
            confidence = 0.7 if match else 0.3
            return {
                "match": match, 
                "confidence": confidence,
                "explanation": response
            }
            
    def compare_images(self, image_url_1, image_url_2):
        """Compare two images and determine if they show the same product"""
        # Encode both images
        image_data_1 = self._encode_image(image_url_1)
        image_data_2 = self._encode_image(image_url_2)
        
        if not image_data_1 or not image_data_2:
            return {
                "match": False, 
                "confidence": 0.0,
                "explanation": "One or both image downloads failed"
            }
            
        prompt = """
        Compare these two product images and determine if they show the SAME product.
        
        Focus on:
        1. Brand match
        2. Product type match
        3. Product features match
        4. Overall visual appearance
        
        Look at the actual products shown in both images, not just text.
        
        Respond with JSON: 
        {
            "match": true/false,
            "confidence": 0.0-1.0,
            "explanation": "detailed explanation of why the images do or don't match"
        }
        """
        
        messages = [{
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_data_1}"}},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_data_2}"}}
            ]
        }]
        
        response = self._get_response(messages)
        if not response:
            return {
                "match": False, 
                "confidence": 0.0,
                "explanation": "API error"
            }
            
        return self._parse_json_response(response)
    
    def process_dataframe(self, df):
        """Process entire dataframe with two image URLs per row"""
        # Create a copy of the original dataframe to preserve all columns
        results_df = df.copy()
        
        # Add new columns for the match results
        results_df['IMAGE_MATCH'] = "No"  
        results_df['CONFIDENCE'] = 0.0
        results_df['explanation'] = ''
        
        for i, row in df.iterrows():
            try:
                image_url_1 = row['IMAGE_URL_1']
                image_url_2 = row['IMAGE_URL_2']
                
                print(f"Processing {i+1}/{len(df)}: Comparing images")
                match_result = self.compare_images(image_url_1, image_url_2)
                
                # Update the new columns with match results - convert boolean to Yes/No
                results_df.at[i, 'IMAGE_MATCH'] = "Yes" if match_result['match'] else "No"
                results_df.at[i, 'CONFIDENCE'] = match_result.get('confidence', 0.0)
                results_df.at[i, 'explanation'] = match_result['explanation']
                
                if (i + 1) % 5 == 0:
                    print(f"Completed {i + 1}/{len(df)} rows...")
                    
                time.sleep(1)  
                
            except Exception as e:
                print(f"Error processing row {i}: {e}")
                results_df.at[i, 'IMAGE_MATCH'] = "No"
                results_df.at[i, 'CONFIDENCE'] = 0.0
                results_df.at[i, 'explanation'] = f"Error: {str(e)}"
                
        return results_df

# Main function to run the pipeline
def run_pipeline(input_file, output_file='Image_Vs_Image_Audit_Output.xlsx'):
    """Run the image comparison pipeline"""
    if input_file.endswith('.csv'):
        df = pd.read_csv(input_file)
    else:
        df = pd.read_excel(input_file)
    
    # Verify required columns exist
    required_columns = ['IMAGE_URL_1', 'IMAGE_URL_2']
    missing_columns = [col for col in required_columns if col not in df.columns]
    
    if missing_columns:
        raise ValueError(f"Input file missing required columns: {missing_columns}")
    
    # Process data
    comparator = ImageComparator()
    results_df = comparator.process_dataframe(df)
    
    # Save results - exclude explanation column from output
    output_df = results_df.drop(columns=['explanation'])
    output_df.to_excel(output_file, index=False)
    print(f"Processed {len(df)} rows. Results saved to {output_file}")
    
    return results_df

if __name__ == "__main__":
    input_file = 'Image_Vs_Image_Audit_Input.xlsx'  
    results = run_pipeline(input_file)
    print(results.head())