# Product Audit Tool

A Streamlit-based application for performing various product data audits including name validation, image comparison, and taxonomy verification.

## Features

- **Name Audit**: Validates product names and suggests improvements
- **Image vs Image Audit**: Compares two product images to determine if they show the same product
- **Name vs Image Audit**: Checks if a product image matches the product name
- **Name vs Taxonomy Audit**: Validates if a product name matches its assigned category path

## Requirements

- Python 3.9+
- Virtual environment (recommended)

## Installation

1. Download the project files to your local machine and navigate to the project directory:

```bash
cd /path/to/One_Stop_Tool
```

2. Create and activate a virtual environment:

```bash
# On macOS/Linux
python -m venv .venv
source .venv/bin/activate

# On Windows
python -m venv .venv
.venv\Scripts\activate
```

3. Install the required packages:

```bash
pip install -r requirements.txt
```

## Running the Application

You can run the application with a single command:

```bash
cd /path/to/One_Stop_Tool && source .venv/bin/activate && streamlit run streamlit_app.py
```

Or step by step:

1. Activate the virtual environment (if not already activated):
```bash
source .venv/bin/activate  # On macOS/Linux
```

2. Run the Streamlit application:
```bash
streamlit run streamlit_app.py
```

3. The application will open in your default web browser, typically at http://localhost:8501

## Required Files

The following files are required for the application to function properly:

### Core Python Files
- `streamlit_app.py` - Main Streamlit application
- `Name_Audit.py` - Name audit functionality
- `Image_Vs_Image_Audit.py` - Image comparison functionality
- `Name_Vs_Image_Audit.py` - Name vs image comparison
- `Name_Vs_Taxonomy_Audit.py` - Name vs taxonomy validation

### Data Files
- `taxonomy_list.csv` - Required for the Name vs Taxonomy Audit feature

## Input File Format

### Name Audit
Excel or CSV file with the following columns:
- `RAW_NAME`: The original product name
- `DISPLAY_NAME`: The display name

### Image vs Image Audit
Excel or CSV file with the following columns:
- `IMAGE_URL_1`: URL of the first image
- `IMAGE_URL_2`: URL of the second image

### Name vs Image Audit
Excel or CSV file with the following columns:
- `DISPLAY_NAME`: The product name
- `IMAGE_URL`: URL of the product image

### Name vs Taxonomy Audit
Excel or CSV file with the following columns:
- `PRODUCT_NAME`: The product name
- `PRODUCT_CATEGORY_PATH`: The taxonomy category path

## Output

The application generates output Excel files for each audit type:
- `Name_Audit_Output.xlsx`
- `Image_Vs_Image_Audit_Output.xlsx`
- `Name_Vs_Image_Audit_Output.xlsx`
- `Name_Vs_Taxonomy_Audit_Output.xlsx`

## Troubleshooting

- If you encounter any issues with OpenAI API access, check your API configuration in the respective Python files.
- For image processing issues, ensure that the image URLs are accessible and valid.
- If the application fails to start, verify that all required packages are installed correctly.

## Dependencies

The application relies on the following major Python packages:
- streamlit (1.31.0+)
- pandas (2.0.0+)
- numpy (1.24.0+)
- scikit-learn (1.2.0+)
- openai (1.14.0)
- httpx (0.26.0)
- requests (2.28.0+)
- pillow (9.0.0+)
