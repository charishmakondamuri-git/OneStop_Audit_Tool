import pandas as pd
import traceback
import time
import httpx
from openai import OpenAI

http_client = httpx.Client()
client = OpenAI(
    api_key="unused",
    base_url="https://aigateway.instacart.tools/unified/product_matches/v1",
    http_client=http_client
)

def get_response(prompt):
    try:
        response = client.chat.completions.create(
            model="claude-3.7-sonnet",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1000,
            temperature=0
        )
        return response.choices[0].message.content.strip()
    except Exception:
        traceback.print_exc()
        return None

def step_1_prompt(raw_name, display_name):
    return f"""
You are validating if two product names refer to the **same product**, despite wording differences. Small changes like "Bag", "Deli Meat", plural vs singular, or spacing **should be ignored**.

Rules:
- If the **core product type** are the same, reply **Yes**.
- If the products are completely different, reply **No**.
- Make a note for organic or deli products as they are different products and should not be matched with non-organic and non-deli products.
- You must reply **only** with one word: **Yes** or **No**. No punctuation or explanation.

Examples:
RAW_NAME: Tri Color Grapes  
DISPLAY_NAME: Tricolor Grapes Bag  
Output: Yes

RAW_NAME: Foster Farms Hickory Smoked Turkey Breast  
DISPLAY_NAME: Foster Farms Hickory Smoked Turkey Breast, Deli Meat  
Output: Yes

RAW_NAME: Green Bean Saute  
DISPLAY_NAME: French Green Beans  
Output: No

RAW_NAME: Organic Avocados  
DISPLAY_NAME: Avocados Bag  
Output: No

RAW_NAME: Foster Farms Oven Roasted Turkey Breast  
DISPLAY_NAME: Foster Farms Oven Roasted Turkey Breast  
Output: Yes

RAW_NAME: Bud Light Seltzer Variety Pack  
DISPLAY_NAME: Bud Light Variety Pack, Hard Seltzer, Gluten Free, 12 Pack, 12 Fl Oz Slim Cans  
Output: Yes

RAW_NAME: Schweppes Diet Tonic  
DISPLAY_NAME: Schweppes Tonic Water  
Output: Yes


RAW_NAME: COVERGIRL Cheekers Blush Iced Cappuccino 130 - 0.12 Oz
DISPLAY_NAME: COVERGIRL Cheekers Blendable Powder Blush, Iced Cappucino
Output: Yes

Now evaluate:
RAW_NAME: {raw_name}  
DISPLAY_NAME: {display_name}  
Output:"""

def process_excel(input_excel_path, output_excel_path):
    import pandas as pd
    import time

    df = pd.read_excel(input_excel_path)

    step1_matches = []

    total_rows = len(df)
    print(f"🔄 Starting LLM evaluation for {total_rows} rows...\n")

    for idx, row in df.iterrows():
        raw_name = str(row['RAW_NAME']).strip()
        display_name = str(row['DISPLAY_NAME']).strip()

        # Step 1 only
        prompt1 = step_1_prompt(raw_name, display_name)
        result1 = get_response(prompt1)
        result1_clean = "Yes" if result1 and result1.strip().lower().startswith("yes") else "No"
        step1_matches.append(result1_clean)

        # ✅ Progress print
        print(f"✅ Row {idx + 1}/{total_rows}: NAME_MATCH = {result1_clean}")
        time.sleep(1)

    # Save results
    df['NAME_MATCH'] = step1_matches
    df.to_excel(output_excel_path, index=False)

    print(f"\n✅ Finished processing {total_rows} rows.")
    print(f"📄 Results saved to: {output_excel_path}")

if __name__ == "__main__":
    process_excel("Name_Audit_Input.xlsx", "Name_Audit_Output.xlsx")